---
name: Rule improvement suggestion
about: Suggest an improvement for a rule
title: ''
labels: ''
assignees: ''

---

### Analyzer

**Diagnostic ID**: [CA1716](https://docs.microsoft.com/dotnet/fundamentals/code-analysis/quality-rules/ca1716)

### Describe the improvement

<!-- A clear and concise description of the improvement. -->

### Describe suggestions on how to achieve the rule

<!-- A clear description to how to achieve the rule. -->

### Additional context

<!-- Add any other context or screenshots about the rule request here. -->
