---
name: New rule suggestion
about: Suggest a new rule
title: ''
labels: 'new-rule'
assignees: ''

---

<!-- Please refer to https://github.com/dotnet/roslyn-analyzers/blob/master/GuidelinesForNewRules.md -->

### Describe the problem you are trying to solve

<!-- A clear and concise description of what you want to the rule to prevent. -->

### Describe suggestions on how to achieve the rule

<!-- A clear description to how to achieve the rule. Suggest how a code-fix could automatically fix the issue/problem -->

### Additional context

<!-- Add any other context or screenshots about the rule request here. -->
