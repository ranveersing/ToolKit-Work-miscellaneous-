# RULEID: Friendly rule name

## Cause

## Rule description

## How to fix violations

## When to suppress warnings

## Example of a violation

### Description

### Code

```
```

## Example of how to fix

### Description

### Code

```
```

## Related rules

[RULEID: Friendly related rule name](https://stable-uris-r-us.com/MyRuleId_MyFriendlyRuleName.md)
