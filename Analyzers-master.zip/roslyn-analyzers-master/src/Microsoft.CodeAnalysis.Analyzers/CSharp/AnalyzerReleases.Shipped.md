## Release 2.9.8

### New Rules
Rule ID | Category | Severity | Notes
--------|----------|----------|-------
RS1014 | MicrosoftCodeAnalysisCorrectness | Warning | CSharpImmutableObjectMethodAnalyzer