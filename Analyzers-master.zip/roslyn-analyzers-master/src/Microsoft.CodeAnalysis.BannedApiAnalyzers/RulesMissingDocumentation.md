# Rules without documentation

Rule ID | Missing Help Link | Title |
--------|-------------------|-------|
RS0035 |  | External access to internal symbols outside the restricted namespace(s) is prohibited |
